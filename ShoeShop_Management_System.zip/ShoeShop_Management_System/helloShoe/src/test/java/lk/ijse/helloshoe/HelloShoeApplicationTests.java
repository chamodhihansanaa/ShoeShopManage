package lk.ijse.helloshoe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloShoeApplicationTests {

    @Test
    void contextLoads() {
    }

}
