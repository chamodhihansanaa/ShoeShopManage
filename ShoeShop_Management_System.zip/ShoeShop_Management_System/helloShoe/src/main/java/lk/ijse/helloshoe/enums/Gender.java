package lk.ijse.helloshoe.enums;

public enum Gender {
    MALE,FEMALE
}
