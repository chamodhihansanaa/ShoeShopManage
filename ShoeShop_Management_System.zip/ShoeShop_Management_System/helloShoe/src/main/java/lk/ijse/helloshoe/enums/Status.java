package lk.ijse.helloshoe.enums;

public enum Status {
    LOW,AVAILABLE,NOT_AVAILABLE
}
