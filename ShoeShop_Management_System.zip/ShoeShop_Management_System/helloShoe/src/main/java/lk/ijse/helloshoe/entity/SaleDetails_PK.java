package lk.ijse.helloshoe.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaleDetails_PK {
    private String orderNo;
    private String itemCode;
}
