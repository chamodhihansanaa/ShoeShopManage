package lk.ijse.helloshoe.enums;

public enum Category {
    INTERNATIONAL, LOCAL
}
