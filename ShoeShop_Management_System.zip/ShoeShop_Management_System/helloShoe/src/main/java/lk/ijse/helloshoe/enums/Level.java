package lk.ijse.helloshoe.enums;

public enum Level {
    GOLD,SILVER,BRONZE,NEW
}
