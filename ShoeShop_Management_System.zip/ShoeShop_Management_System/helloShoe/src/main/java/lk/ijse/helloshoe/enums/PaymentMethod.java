package lk.ijse.helloshoe.enums;

public enum PaymentMethod {
    CARD,CASH
}
